def unused_function(arg):
    #This function is not used anywhere, and its argument 'arg' is also unused.
    #Vulture should assign a 100% confidence value for both the function and its argument.
    pass

def used_function():
    print('This function is used in the script.')

def unreachable_code():
    print('This line is unreachable code')
    return
    
if __name__ == '__main__':
    used_function()
    unreachable_code()