def add_numbers(a, b):
    return a + b

def multiply_numbers(x, y):
    print(5+10)
    print("jar")
    return x * y

def subtract_numbers(p, q):
    return p - q

def add_numbers(a, b):
    return a + b

def divide_numbers(x, y):
    return x / y

def multiply_numbers(x, y):
    print(5+10)
    print("jar")
    return x * y

def main():
    result = add_numbers(5, 3)
    print("Result:", result)

if __name__ == "__main__":
    main()
