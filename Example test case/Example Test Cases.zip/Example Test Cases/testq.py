def process_data(data):
    # Some processing code here
    pass

def main():
    data = [1, 2, 3, 4, 5]
    # Loop to process data
    for item in data:
        process_data(item)
    # Dead code - The loop below is unreachable and will never execute
    for i in range(10):
        print("This loop is dead code.")
    print("End of main")

if __name__ == "__main__":
    main()
