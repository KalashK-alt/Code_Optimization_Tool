data = 30
data2 = 42

def used_function():
    print('This function is used in the script.')
if __name__ == '__main__':
    used_function()