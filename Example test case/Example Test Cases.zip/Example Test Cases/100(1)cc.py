def add_numbers(a, b):
    sum_result = a + b
    return sum_result

def subtract_numbers(a, b):
    diff_result = a - b
    return diff_result

def multiply_numbers(a, b):
    product_result = a * b
    return product_result

def divide_numbers(a, b):
    if b != 0:
        division_result = a / b
        return division_result
    else:
        return "Division by zero error"

def add_numbers_cloned(a, b):
    result = a + b  # This is similar to the first function
    return result

def subtract_numbers_modified(a, b):
    result = a - b  # Similar to subtract_numbers with minor differences
    return result

def calculate_area_of_rectangle(length, width):
    area = length * width
    return area

def calculate_area_of_square(side):
    return side * side

def calculate_area_of_rectangle_modified(length, width):
    # Similar to calculate_area_of_rectangle but with added comments
    area = length * width
    return area

def find_maximum(a, b):
    if a > b:
        return a
    else:
        return b

def find_minimum(a, b):
    if a < b:
        return a
    else:
        return b

def calculate_power(base, exponent):
    result = 1
    for _ in range(exponent):
        result *= base
    return result

def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

def greet_user(name):
    return f"Hello, {name}!"

def check_even_or_odd(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"

def reverse_string(s):
    return s[::-1]

def count_vowels(s):
    vowels = "aeiouAEIOU"
    count = 0
    for char in s:
        if char in vowels:
            count += 1
    return count

def is_palindrome(s):
    return s == s[::-1]

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key

def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]

        merge_sort(left_half)
        merge_sort(right_half)

        i = j = k = 0
        while i < len(left_half) and j < len(right_half):
            if left_half[i] < right_half[j]:
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
            k += 1

        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1

def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[len(arr) // 2]
        left = [x for x in arr if x < pivot]
        middle = [x for x in arr if x == pivot]
        right = [x for x in arr if x > pivot]
        return quick_sort(left) + middle + quick_sort(right)

def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1
