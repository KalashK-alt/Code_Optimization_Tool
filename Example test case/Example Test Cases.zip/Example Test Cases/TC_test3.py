def unused_function_1():
    print('This function is not used anywhere.')

def used_function():
    print('This function is used in the script.')
    unused_function_1()
if __name__ == '__main__':
    used_function()