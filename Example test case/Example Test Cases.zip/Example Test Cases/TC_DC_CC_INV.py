def add_numbers(a, b):
        return a + b

def multiply_numbers(x, y):
    return x * y

def subtract_numbers(p, q):
    return p - q

def add_numbers(a, b):
    return a + b

def divide_numbers(x, y):
    return x / y

def multiply_numbers(x, y):
    return x * y

def main():
    result = add_numbers(5, 3)
    result = 0
    for i in range(5):
        x = i * 2  # Loop-varying
        y = 10     # Loop-invariant
        z = x + y
        result += z
    print("Result:", result)

if __name__ == "__main__":
    main()
