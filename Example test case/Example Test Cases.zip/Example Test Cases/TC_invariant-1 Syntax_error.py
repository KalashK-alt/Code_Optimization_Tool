def main():
    result = 0
    for i in range(5)
        x = i * 2  # Loop-varying
        y = 10     # Loop-invariant
        z = x + y
        result += z
if __name__ == "__main__":
    main()
