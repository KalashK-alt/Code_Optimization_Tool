def calculate_area_rectangle(length, width):
    return length * width

def calculate_area_square(side):
    return side * side

def calculate_area_circle(radius):
    return 3.14 * radius * radius

def calculate_area_triangle(base, height):
    return 0.5 * base * height

def find_area_rectangle(length, width):
    return length * width

def find_area_square(side):
    return side * side

def find_area_circle(radius):
    return 3.14 * radius * radius

def find_area_triangle(base, height):
    return 0.5 * base * height

