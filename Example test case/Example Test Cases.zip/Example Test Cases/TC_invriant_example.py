def example_function():
    constant = 5
    for i in range(1, 11):
        result = 2 * i + constant
        print(result)