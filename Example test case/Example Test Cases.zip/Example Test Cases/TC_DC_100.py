def add_numbers(a, b):
        return a + b

def multiply_numbers(x, y):
    return x * y

def subtract_numbers(p, q):
    return p - q

def add_numbers(a, b):
    return a + b

def divide_numbers(x, y):
    return x / y

def multiply_numbers(x, y):
    return x * y

data = 30
data2 = 42

def used_function():
    print('This function is used in the script.')
    
def unused_function(arg):
    #This function is not used anywhere, and its argument 'arg' is also unused.
    #Vulture should assign a 100% confidence value for both the function and its argument.
    pass

def used_function():
    print('This function is used in the script.')

def unreachable_code():
    print('This line is unreachable code')
    return
    

def main():
    result = add_numbers(5, 3)
    result = 0
    for i in range(5):
        x = i * 2  # Loop-varying
        y = 10     # Loop-invariant
        z = x + y
        result += z
    print("Result:", result)
    
    used_function()
    unreachable_code()
    
##################################################################
def add_numbers(a, b):
        return a + b

def multiply_numbers(x, y):
    return x * y

def subtract_numbers(p, q):
    return p - q

def add_numbers(a, b):
    return a + b

def divide_numbers(x, y):
    return x / y

def multiply_numbers(x, y):
    return x * y

data = 30
data2 = 42

def used_function():
    print('This function is used in the script.')
    
def unused_function(arg):
    #This function is not used anywhere, and its argument 'arg' is also unused.
    #Vulture should assign a 100% confidence value for both the function and its argument.
    pass

def used_function():
    print('This function is used in the script.')

def unreachable_code():
    print('This line is unreachable code')
    return
    

def main():
    result = add_numbers(5, 3)
    result = 0
    for i in range(5):
        x = i * 2  # Loop-varying
        y = 10     # Loop-invariant
        z = x + y
        result += z
    print("Result:", result)
    
    used_function()
    unreachable_code()


if __name__ == "__main__":
    main()
    used_function()
    unreachable_code()
